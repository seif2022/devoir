$(window).load(function(){
      $('#carousel').flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: false,
        slideshow: false,
        itemWidth: 210,
        itemMargin: 5,
        asNavFor: '#slider'
      });

      $('#slider').flexslider({
        animation: "slide",
        controlNav: false,
        animationLoop: false,
        slideshow: false,
        sync: "#carousel",
        start: function(slider){
          $('body').removeClass('loading');
        }
      });
    });
	$(window).scroll(function(){
    if ($(this).scrollTop() > 100) {
       $('.navigationBlk').addClass('newClass');
    } else {
       $('.navigationBlk').removeClass('newClass');
    }
});

$('#carousel01').owlCarousel({
    loop:true,
    margin:30,
    nav:true,
	dots:false,
    responsive:{
        0:{
            items:4
        },
		580:{
            items:4
        },
        767:{
            items:4
        },
        1199:{
            items:4
        },
		1600:{
            items:4
        }
		
    }
})